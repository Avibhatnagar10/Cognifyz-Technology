from flask import Flask, request, jsonify, render_template_string
import re
import logging

app = Flask(__name__)

# Configure logging
logging.basicConfig(filename='form_submissions.log', level=logging.INFO, format='%(asctime)s - %(message)s')

@app.route('/')
def form():
    return render_template_string(open('form.html').read())

@app.route('/submit', methods=['POST'])
def submit():
    name = request.form.get('name')
    email = request.form.get('email')
    age = request.form.get('age')

    errors = {}

    if not name:
        errors['name'] = 'Name is required'
    if not email or not re.match(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$', email):
        errors['email'] = 'Invalid email format'
    if not age or int(age) < 18:
        errors['age'] = 'Age must be 18 or older'

    if errors:
        return jsonify(success=False, errors=errors), 400

    # Temporary storage (in-memory for this example)
    temp_storage = {'name': name, 'email': email, 'age': age}
    
    # Log the validated data
    logging.info('Validated submission: %s', temp_storage)

    return jsonify(success=True, data=temp_storage)

if __name__ == '__main__':
    app.run(debug=True)
