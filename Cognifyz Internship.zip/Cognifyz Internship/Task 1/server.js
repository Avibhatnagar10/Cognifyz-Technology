// server.js

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 5500;

// Parse URL-encoded bodies for form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static('public'));

// Render the index.html file
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Handle form submission
app.post('/submit', (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const role = req.body.role;
    // Here you can process the form data as needed
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Role:', role);
    // Send a response to the client
    res.send('Form submitted successfully!');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

// server.js

// Add this line to import EJS
const ejs = require('ejs');

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Render the index.ejs file instead of index.html
app.get('/', (req, res) => {
    res.render('index');
});

