const apiUrl = 'http://localhost:3000/items';

// Run when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  fetchItems(); // Fetch and display items when the page loads

  // Handle form submission to add a new item
  document.getElementById('item-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const itemName = document.getElementById('item-name').value;
    await addItem({ name: itemName });
    document.getElementById('item-name').value = ''; // Clear the input field
    fetchItems(); // Refresh the list of items
  });
});

// Fetch items from the server and display them
async function fetchItems() {
  const response = await fetch(apiUrl);
  const items = await response.json();
  const itemsContainer = document.getElementById('items');
  itemsContainer.innerHTML = ''; // Clear existing items
  items.forEach(item => {
    const itemDiv = document.createElement('div');
    itemDiv.classList.add('item');
    itemDiv.innerHTML = `
      <span>${item.name}</span>
      <button onclick="deleteItem(${item.id})">Delete</button>
    `;
    itemsContainer.appendChild(itemDiv);
  });
}

// Add a new item to the server
async function addItem(item) {
  await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(item)
  });
}

// Delete an item from the server
async function deleteItem(id) {
  await fetch(`${apiUrl}/${id}`, {
    method: 'DELETE'
  });
  fetchItems(); // Refresh the list of items
}
