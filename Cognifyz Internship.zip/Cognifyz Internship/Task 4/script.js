// Form validation and dynamic updates
document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const password = document.getElementById('password').value;
    const errorMessage = validatePassword(password);
    if (errorMessage) {
        document.getElementById('error-message').innerText = errorMessage;
    } else {
        document.getElementById('error-message').innerText = 'Password is valid.';
        // You can add form submission code here
    }
});

document.getElementById('password').addEventListener('input', function(event) {
    const password = event.target.value;
    const strength = getPasswordStrength(password);
    document.getElementById('passwordStrength').innerText = `Password strength: ${strength}`;
});

function validatePassword(password) {
    const minLength = 8;
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (password.length < minLength) {
        return 'Password must be at least 8 characters long.';
    }
    if (!regex.test(password)) {
        return 'Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.';
    }
    return '';
}

function getPasswordStrength(password) {
    let strength = 'Weak';
    if (password.length >= 8 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /\d/.test(password) && /[@$!%*?&]/.test(password)) {
        strength = 'Strong';
    } else if (password.length >= 6) {
        strength = 'Medium';
    }
    return strength;
}

// Client-side routing
window.addEventListener('hashchange', function() {
    const hash = window.location.hash.substring(1);
    loadContent(hash);
});

function loadContent(page) {
    let content = '';
    switch(page) {
        case 'home':
            // content = '<p>Welcome to the Home Page</p>';
            document.getElementById('registrationForm').style.display = 'block';
            break;
        case 'about':
            content = '<h1>About Page</h1><p>Learn more about us on this page</p>';
            document.getElementById('registrationForm').style.display = 'none';
            break;
        case 'contact':
            content = '<h1>Contact Page</h1><p>Get in touch with us</p>';
            document.getElementById('registrationForm').style.display = 'none';
            break;
        default:
            content = '<p>Welcome to the Home Page</p>';
            document.getElementById('registrationForm').style.display = 'block';
    }
    document.getElementById('content').innerHTML = content;
}

// Load the default content based on the current hash or default to 'home'
loadContent(window.location.hash.substring(1) || 'home');
